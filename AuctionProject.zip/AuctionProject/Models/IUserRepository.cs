﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Threading.Tasks;

//namespace AuctionProject.Models
//{
//    public interface IUserRepository
//    {
//        //   C r e a t e

//        public IdentityUser AddUser(User user);

//        //   R e a d 

//        public IQueryable<User> GetAllUsers();
//        public User GetUserByEmail(string email);
//        public User GetUserById(int id);

//        //   U p d a t e

//        public User UpdateUser(User user);

//        //   D e l e t e

//        public bool DeleteUser(int id);

//        public bool DeleteUser(User user);
//    }
//}
